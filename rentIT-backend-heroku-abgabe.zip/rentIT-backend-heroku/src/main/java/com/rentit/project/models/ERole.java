package com.rentit.project.models;

public enum ERole {
	
	ROLE_USER,
	ROLE_MODERATOR,
	ROLE_ADMIN

}

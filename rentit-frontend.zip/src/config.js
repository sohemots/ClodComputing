export const API_ENDPOINT = 'https://rentit-thb.herokuapp.com/api/' // Heroku
// export const API_ENDPOINT = 'http://localhost:8080/api/' // local
